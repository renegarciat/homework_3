cd CFiles
g++  -o main main.cpp Serial.cpp -lm -Wno-write-strings &&
./main
